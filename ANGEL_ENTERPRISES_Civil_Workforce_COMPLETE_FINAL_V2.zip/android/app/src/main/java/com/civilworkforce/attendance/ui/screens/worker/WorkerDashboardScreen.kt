package com.civilworkforce.attendance.ui.screens.worker

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.civilworkforce.attendance.data.AttendanceRepository
import com.civilworkforce.attendance.data.AuthRepository
import com.civilworkforce.attendance.data.WorkerRepository
import com.civilworkforce.attendance.model.AttendanceRecord
import com.civilworkforce.attendance.model.AttendanceStatus
import com.civilworkforce.attendance.model.Resource
import com.civilworkforce.attendance.model.Worker
import com.civilworkforce.attendance.model.WorkerStatus
import com.civilworkforce.attendance.ui.components.CivilTopAppBar
import com.civilworkforce.attendance.ui.components.ErrorDialog
import com.civilworkforce.attendance.ui.components.LoadingOverlay
import com.civilworkforce.attendance.ui.components.StatusBadge
import com.civilworkforce.attendance.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WorkerDashboardUiState(
    val worker: Worker? = null,
    val todayAttendance: AttendanceRecord? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val comingSoonModule: String? = null
)

class WorkerDashboardViewModel(
    private val workerRepository: WorkerRepository,
    private val authRepository: AuthRepository,
    private val attendanceRepository: AttendanceRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkerDashboardUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadWorkerProfile()
    }

    fun loadWorkerProfile() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            when (val userRes = authRepository.getCurrentUser()) {
                is Resource.Success -> {
                    val user = userRes.data
                    if (user != null) {
                        when (val workerRes = workerRepository.getWorkerByUid(user.uid)) {
                            is Resource.Success -> {
                                val worker = workerRes.data
                                var att: AttendanceRecord? = null
                                if (worker != null) {
                                    val attRes = attendanceRepository.getTodayAttendance(worker.workerId)
                                    if (attRes is Resource.Success) {
                                        att = attRes.data
                                    }
                                }
                                _uiState.value = _uiState.value.copy(
                                    worker = worker,
                                    todayAttendance = att,
                                    isLoading = false
                                )
                            }
                            is Resource.Error -> {
                                _uiState.value = _uiState.value.copy(
                                    isLoading = false,
                                    errorMessage = workerRes.message
                                )
                            }
                            Resource.Loading -> Unit
                        }
                    } else {
                        _uiState.value = _uiState.value.copy(isLoading = false)
                    }
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = userRes.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun showComingSoon(moduleName: String) {
        _uiState.value = _uiState.value.copy(comingSoonModule = moduleName)
    }

    fun dismissComingSoon() {
        _uiState.value = _uiState.value.copy(comingSoonModule = null)
    }

    fun logout(onLoggedOut: () -> Unit) {
        viewModelScope.launch {
            authRepository.logout()
            onLoggedOut()
        }
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}

data class FutureModuleItem(
    val title: String,
    val icon: ImageVector,
    val description: String
)

@Composable
fun WorkerDashboardScreen(
    viewModel: WorkerDashboardViewModel,
    onNavigateToProfile: () -> Unit,
    onNavigateToQrScanner: () -> Unit,
    onLogout: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    val futureModules = listOf(
        FutureModuleItem("Leave", Icons.Default.EventBusy, "Request Site Leave & Casual Off"),
        FutureModuleItem("Overtime", Icons.Default.MoreTime, "Overtime Shift Request & Log"),
        FutureModuleItem("Salary", Icons.Default.Payments, "Wage Slips & Pay Rate Details"),
        FutureModuleItem("Documents", Icons.Default.Description, "Certifications & Safety Passes")
    )

    Scaffold(
        topBar = {
            CivilTopAppBar(
                title = "Worker Dashboard",
                actions = {
                    IconButton(onClick = viewModel::loadWorkerProfile) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                    }
                    IconButton(onClick = onNavigateToProfile) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Profile", tint = Color.White)
                    }
                    IconButton(onClick = { viewModel.logout(onLogout) }) {
                        Icon(Icons.Default.Logout, contentDescription = "Logout", tint = Color.White)
                    }
                }
            )
        },
        containerColor = ConcreteBackground
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Identity Summary Card
                val worker = uiState.worker
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = ConstructionSlate),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onNavigateToProfile)
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = worker?.fullName ?: "Active Worker",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                            StatusBadge(worker?.status?.name ?: "ACTIVE")
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text("Worker ID", fontSize = 11.sp, color = Color.LightGray)
                                Text(worker?.workerId ?: "W-1042", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = SafetyAmberLight)
                            }
                            Column {
                                Text("Job Role", fontSize = 11.sp, color = Color.LightGray)
                                Text(worker?.jobRole ?: "Civil Worker", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                            Column {
                                Text("Batch", fontSize = 11.sp, color = Color.LightGray)
                                Text(worker?.batchNumber ?: "BATCH-A", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = ConstructionSteel)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = SafetyAmber, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Assigned Site: ${worker?.siteId ?: "Main Construction Site"}",
                                fontSize = 13.sp,
                                color = Color.White
                            )
                        }
                    }
                }

                // Phase 2 Smart Attendance Live Card
                val isWorkerActive = worker?.status == WorkerStatus.ACTIVE
                val attendance = uiState.todayAttendance

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = ConcreteSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = if (isWorkerActive) SafetyAmber else ConstructionSteel,
                                    modifier = Modifier.size(24.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Smart Attendance",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = ConstructionSlate
                                )
                            }

                            if (!isWorkerActive) {
                                StatusBadge("RESTRICTED")
                            } else if (attendance == null) {
                                StatusBadge("NOT CHECKED IN")
                            } else if (attendance.status == AttendanceStatus.CHECKED_IN) {
                                StatusBadge("CHECKED IN")
                            } else {
                                StatusBadge("COMPLETED")
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        if (!isWorkerActive) {
                            Text(
                                text = "Attendance scanning is restricted to approved ACTIVE civil workers. Current account status is ${worker?.status ?: "PENDING"}.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.error
                            )
                        } else if (attendance == null) {
                            Text(
                                text = "You have not checked in for today's shift yet. Scan the supervisor's rotating 30s QR code at your assigned site (${worker.siteId}).",
                                style = MaterialTheme.typography.bodySmall,
                                color = ConstructionSlate
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onNavigateToQrScanner,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = SafetyAmber, contentColor = ConstructionSlate)
                            ) {
                                Icon(Icons.Default.QrCodeScanner, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Scan Site QR to Check In", fontWeight = FontWeight.Bold)
                            }
                        } else if (attendance.status == AttendanceStatus.CHECKED_IN) {
                            Text(
                                text = "Currently Checked In on site ${attendance.siteId}. Remember to scan the live site QR to check out before leaving.",
                                style = MaterialTheme.typography.bodySmall,
                                color = ConstructionSlate
                            )
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = onNavigateToQrScanner,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = ConstructionSlate, contentColor = Color.White)
                            ) {
                                Icon(Icons.Default.Logout, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Scan Site QR to Check Out", fontWeight = FontWeight.Bold)
                            }
                        } else {
                            Text(
                                text = "Shift completed for today (${attendance.date}). Both check-in and check-out records have been securely recorded in Firestore.",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusActiveGreen
                            )
                        }
                    }
                }

                Text(
                    text = "Workforce Modules",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ConstructionSlate
                )

                // Grid of Modules with "Coming in future phases"
                LazyVerticalGrid(
                    columns = GridCells.Fixed(2),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(futureModules) { mod ->
                        Card(
                            shape = RoundedCornerShape(10.dp),
                            colors = CardDefaults.cardColors(containerColor = ConcreteSurface),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(120.dp)
                                .clickable { viewModel.showComingSoon(mod.title) }
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(14.dp),
                                verticalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = mod.icon,
                                        contentDescription = null,
                                        tint = ConstructionSteel,
                                        modifier = Modifier.size(24.dp)
                                    )
                                    Surface(
                                        shape = RoundedCornerShape(4.dp),
                                        color = Color(0xFFF1F5F9)
                                    ) {
                                        Text(
                                            text = "Phase 2+",
                                            fontSize = 9.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = ConstructionSteel,
                                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                        )
                                    }
                                }

                                Column {
                                    Text(
                                        text = mod.title,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = ConstructionSlate
                                    )
                                    Text(
                                        text = "Coming in future phases",
                                        fontSize = 11.sp,
                                        color = SafetyAmberDark
                                    )
                                }
                            }
                        }
                    }
                }
            }

            LoadingOverlay(isLoading = uiState.isLoading)

            ErrorDialog(
                errorMessage = uiState.errorMessage,
                onDismiss = viewModel::dismissError
            )

            // Coming soon info dialog
            uiState.comingSoonModule?.let { modName ->
                AlertDialog(
                    onDismissRequest = viewModel::dismissComingSoon,
                    title = { Text("$modName Module", fontWeight = FontWeight.Bold) },
                    text = {
                        Text(
                            text = "$modName functionality is scheduled for rollout in Phase 2 with hardware QR code scanning, geofence validation, and automated payroll synchronization.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = ConstructionSteel
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = viewModel::dismissComingSoon,
                            colors = ButtonDefaults.buttonColors(containerColor = ConstructionSlate)
                        ) {
                            Text("OK", color = Color.White)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    containerColor = Color.White
                )
            }
        }
    }
}
