package com.civilworkforce.attendance.data

import com.civilworkforce.attendance.model.Resource
import com.civilworkforce.attendance.model.UserStatus
import com.civilworkforce.attendance.model.Worker
import com.civilworkforce.attendance.util.FirebaseErrorParser
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

interface WorkerRepository {
    suspend fun getWorkers(searchQuery: String? = null, statusFilter: UserStatus? = null): Resource<List<Worker>>
    suspend fun getWorkerByUid(uid: String): Resource<Worker?>
    suspend fun getWorkerById(workerId: String): Resource<Worker?>
    suspend fun updateWorkerStatus(workerId: String, newStatus: UserStatus): Resource<Unit>
}

class FirebaseWorkerRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : WorkerRepository {

    override suspend fun getWorkers(searchQuery: String?, statusFilter: UserStatus?): Resource<List<Worker>> {
        return try {
            var query = firestore.collection(FirebaseConstants.COLLECTION_WORKERS)
                .orderBy(FirebaseConstants.FIELD_CREATED_AT)

            val snapshot = query.get().await()
            val list = snapshot.toObjects(Worker::class.java)

            val filtered = list.filter { worker ->
                val matchesStatus = statusFilter == null || worker.status == statusFilter
                val matchesSearch = searchQuery.isNullOrBlank() ||
                        worker.fullName.contains(searchQuery, ignoreCase = true) ||
                        worker.workerId.contains(searchQuery, ignoreCase = true) ||
                        worker.phone.contains(searchQuery, ignoreCase = true) ||
                        worker.jobRole.contains(searchQuery, ignoreCase = true)

                matchesStatus && matchesSearch
            }

            Resource.Success(filtered)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun getWorkerByUid(uid: String): Resource<Worker?> {
        return try {
            val query = firestore.collection(FirebaseConstants.COLLECTION_WORKERS)
                .whereEqualTo(FirebaseConstants.FIELD_UID, uid)
                .limit(1)
                .get()
                .await()

            if (query.isEmpty) {
                Resource.Success(null)
            } else {
                Resource.Success(query.documents.first().toObject(Worker::class.java))
            }
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun getWorkerById(workerId: String): Resource<Worker?> {
        return try {
            val doc = firestore.collection(FirebaseConstants.COLLECTION_WORKERS)
                .document(workerId)
                .get()
                .await()

            if (doc.exists()) {
                Resource.Success(doc.toObject(Worker::class.java))
            } else {
                Resource.Success(null)
            }
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun updateWorkerStatus(workerId: String, newStatus: UserStatus): Resource<Unit> {
        return try {
            val batch = firestore.batch()
            val workerRef = firestore.collection(FirebaseConstants.COLLECTION_WORKERS).document(workerId)
            val workerDoc = workerRef.get().await()

            if (!workerDoc.exists()) {
                return Resource.Error("Worker document does not exist.")
            }

            val uid = workerDoc.getString(FirebaseConstants.FIELD_UID)

            batch.update(workerRef, mapOf(
                FirebaseConstants.FIELD_STATUS to newStatus.name,
                FirebaseConstants.FIELD_UPDATED_AT to Timestamp.now()
            ))

            if (!uid.isNullOrBlank()) {
                val userRef = firestore.collection(FirebaseConstants.COLLECTION_USERS).document(uid)
                batch.update(userRef, mapOf(
                    FirebaseConstants.FIELD_STATUS to newStatus.name,
                    FirebaseConstants.FIELD_UPDATED_AT to Timestamp.now()
                ))
            }

            batch.commit().await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }
}
