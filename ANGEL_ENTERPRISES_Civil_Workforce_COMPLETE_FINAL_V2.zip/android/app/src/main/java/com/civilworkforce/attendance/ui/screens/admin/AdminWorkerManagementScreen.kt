package com.civilworkforce.attendance.ui.screens.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import coil.compose.AsyncImage
import com.civilworkforce.attendance.data.WorkerRepository
import com.civilworkforce.attendance.model.Resource
import com.civilworkforce.attendance.model.UserStatus
import com.civilworkforce.attendance.model.Worker
import com.civilworkforce.attendance.ui.components.CivilTopAppBar
import com.civilworkforce.attendance.ui.components.EmptyStateView
import com.civilworkforce.attendance.ui.components.ErrorDialog
import com.civilworkforce.attendance.ui.components.LoadingOverlay
import com.civilworkforce.attendance.ui.components.StatusBadge
import com.civilworkforce.attendance.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class WorkerManagementUiState(
    val workers: List<Worker> = emptyList(),
    val searchQuery: String = "",
    val selectedStatusFilter: UserStatus? = null,
    val selectedWorker: Worker? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class AdminWorkerViewModel(private val workerRepository: WorkerRepository) : ViewModel() {

    private val _uiState = MutableStateFlow(WorkerManagementUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadWorkers()
    }

    fun loadWorkers() {
        val s = _uiState.value
        viewModelScope.launch {
            _uiState.value = s.copy(isLoading = true, errorMessage = null)
            when (val res = workerRepository.getWorkers(s.searchQuery, s.selectedStatusFilter)) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(workers = res.data, isLoading = false)
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun onSearchChange(query: String) {
        _uiState.value = _uiState.value.copy(searchQuery = query)
        loadWorkers()
    }

    fun onStatusFilterSelect(status: UserStatus?) {
        _uiState.value = _uiState.value.copy(selectedStatusFilter = status)
        loadWorkers()
    }

    fun selectWorker(worker: Worker?) {
        _uiState.value = _uiState.value.copy(selectedWorker = worker)
    }

    fun toggleWorkerStatus(worker: Worker) {
        val newStatus = if (worker.status == UserStatus.ACTIVE) UserStatus.SUSPENDED else UserStatus.ACTIVE
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (val res = workerRepository.updateWorkerStatus(worker.workerId, newStatus)) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(selectedWorker = null)
                    loadWorkers()
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}

@Composable
fun AdminWorkerManagementScreen(
    viewModel: AdminWorkerViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            CivilTopAppBar(
                title = "Workforce Directory",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = viewModel::loadWorkers) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                    }
                }
            )
        },
        containerColor = ConcreteBackground
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            Column(modifier = Modifier.fillMaxSize()) {
                // Search Field
                OutlinedTextField(
                    value = uiState.searchQuery,
                    onValueChange = viewModel::onSearchChange,
                    placeholder = { Text("Search by name, ID, role, or phone...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = ConstructionSteel) },
                    trailingIcon = {
                        if (uiState.searchQuery.isNotEmpty()) {
                            IconButton(onClick = { viewModel.onSearchChange("") }) {
                                Icon(Icons.Default.Close, contentDescription = "Clear", tint = ConstructionSteel)
                            }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 10.dp),
                    shape = RoundedCornerShape(10.dp),
                    singleLine = true
                )

                // Status Filter Chips
                LazyRow(
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    item {
                        FilterChip(
                            selected = uiState.selectedStatusFilter == null,
                            onClick = { viewModel.onStatusFilterSelect(null) },
                            label = { Text("ALL") }
                        )
                    }
                    items(UserStatus.values()) { st ->
                        FilterChip(
                            selected = uiState.selectedStatusFilter == st,
                            onClick = { viewModel.onStatusFilterSelect(st) },
                            label = { Text(st.name) }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Worker List
                if (uiState.workers.isEmpty() && !uiState.isLoading) {
                    EmptyStateView(
                        message = "No workers found matching criteria",
                        icon = Icons.Default.PersonOff
                    )
                } else {
                    LazyColumn(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        items(uiState.workers) { worker ->
                            WorkerCardItem(
                                worker = worker,
                                onClick = { viewModel.selectWorker(worker) }
                            )
                        }
                    }
                }
            }

            LoadingOverlay(isLoading = uiState.isLoading)

            ErrorDialog(
                errorMessage = uiState.errorMessage,
                onDismiss = viewModel::dismissError
            )

            // Worker Detail & Status Toggle Sheet
            uiState.selectedWorker?.let { worker ->
                AlertDialog(
                    onDismissRequest = { viewModel.selectWorker(null) },
                    title = {
                        Text(
                            text = worker.fullName,
                            fontWeight = FontWeight.Bold,
                            color = ConstructionSlate
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    val photoUrl = worker.profilePhoto?.downloadUrl
                                    Surface(
                                        shape = CircleShape,
                                        color = SafetyAmber,
                                        modifier = Modifier.size(48.dp)
                                    ) {
                                        if (!photoUrl.isNullOrBlank()) {
                                            AsyncImage(
                                                model = photoUrl,
                                                contentDescription = null,
                                                contentScale = ContentScale.Crop,
                                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                                            )
                                        } else {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                                            }
                                        }
                                    }
                                    Column {
                                        Text("Worker ID: ${worker.workerId}", fontWeight = FontWeight.SemiBold)
                                        Text(worker.fullName, style = MaterialTheme.typography.bodySmall, color = ConstructionSlate)
                                    }
                                }
                                StatusBadge(worker.status.name)
                            }
                            HorizontalDivider(color = ConcreteBorder)
                            Text("Trade / Role: ${worker.jobRole}", color = ConstructionSteel)
                            Text("Batch: ${worker.batchNumber}", color = ConstructionSteel)
                            Text("Assigned Site: ${worker.siteId}", color = ConstructionSteel)
                            Text("Phone: ${worker.phone}", color = ConstructionSteel)
                            Text("Email: ${worker.email}", color = ConstructionSteel)
                            Text("Joining Date: ${worker.joiningDate}", color = ConstructionSteel)
                            Text("Emergency Contact: ${worker.emergencyContactName} (${worker.emergencyContactPhone})", color = ConstructionSteel)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { viewModel.toggleWorkerStatus(worker) },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (worker.status == UserStatus.ACTIVE) StatusSuspendedRed else StatusActiveGreen
                            )
                        ) {
                            Text(if (worker.status == UserStatus.ACTIVE) "Suspend Worker" else "Activate Worker", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { viewModel.selectWorker(null) }) {
                            Text("Close", color = ConstructionSteel)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    containerColor = Color.White
                )
            }
        }
    }
}

@Composable
fun WorkerCardItem(worker: Worker, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = ConcreteSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                val photoUrl = worker.profilePhoto?.downloadUrl
                Surface(
                    shape = CircleShape,
                    color = SafetyAmber,
                    modifier = Modifier.size(40.dp)
                ) {
                    if (!photoUrl.isNullOrBlank()) {
                        AsyncImage(
                            model = photoUrl,
                            contentDescription = null,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize().clip(CircleShape)
                        )
                    } else {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(Icons.Default.Engineering, contentDescription = null, tint = Color.White, modifier = Modifier.size(22.dp))
                        }
                    }
                }

                Column {
                    Text(
                        text = worker.fullName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = ConstructionSlate
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "${worker.workerId} • ${worker.jobRole} • Batch ${worker.batchNumber}",
                        style = MaterialTheme.typography.bodySmall,
                        color = ConstructionSteel
                    )
                }
            }
            StatusBadge(worker.status.name)
        }
    }
}
