package com.civilworkforce.attendance.ui.screens.admin

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.civilworkforce.attendance.data.RegistrationRepository
import com.civilworkforce.attendance.model.RegistrationStatus
import com.civilworkforce.attendance.model.Resource
import com.civilworkforce.attendance.model.WorkerRegistration
import com.civilworkforce.attendance.ui.components.CivilTopAppBar
import com.civilworkforce.attendance.ui.components.EmptyStateView
import com.civilworkforce.attendance.ui.components.ErrorDialog
import com.civilworkforce.attendance.ui.components.LoadingOverlay
import com.civilworkforce.attendance.ui.components.StatusBadge
import com.civilworkforce.attendance.ui.theme.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class PendingRegistrationsUiState(
    val registrations: List<WorkerRegistration> = emptyList(),
    val selectedRegistration: WorkerRegistration? = null,
    val isLoading: Boolean = false,
    val errorMessage: String? = null
)

class RegistrationViewModel(
    private val registrationRepository: RegistrationRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(PendingRegistrationsUiState())
    val uiState = _uiState.asStateFlow()

    init {
        loadPendingRegistrations()
    }

    fun loadPendingRegistrations() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            when (val res = registrationRepository.getPendingRegistrations()) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(registrations = res.data, isLoading = false)
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun selectRegistration(reg: WorkerRegistration?) {
        _uiState.value = _uiState.value.copy(selectedRegistration = reg)
    }

    fun approve(regId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (val res = registrationRepository.approveRegistration(regId, "admin_current")) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(selectedRegistration = null)
                    loadPendingRegistrations()
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun reject(regId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (val res = registrationRepository.rejectRegistration(regId, "admin_current")) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(selectedRegistration = null)
                    loadPendingRegistrations()
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun suspendRegistration(regId: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)
            when (val res = registrationRepository.suspendRegistration(regId, "admin_current")) {
                is Resource.Success -> {
                    _uiState.value = _uiState.value.copy(selectedRegistration = null)
                    loadPendingRegistrations()
                }
                is Resource.Error -> {
                    _uiState.value = _uiState.value.copy(isLoading = false, errorMessage = res.message)
                }
                Resource.Loading -> Unit
            }
        }
    }

    fun dismissError() {
        _uiState.value = _uiState.value.copy(errorMessage = null)
    }
}

@Composable
fun PendingRegistrationsScreen(
    viewModel: RegistrationViewModel,
    onNavigateBack: () -> Unit
) {
    val uiState by viewModel.uiState.collectAsState()

    Scaffold(
        topBar = {
            CivilTopAppBar(
                title = "Pending Registrations",
                canNavigateBack = true,
                onNavigateBack = onNavigateBack,
                actions = {
                    IconButton(onClick = viewModel::loadPendingRegistrations) {
                        Icon(Icons.Default.Refresh, contentDescription = "Refresh", tint = Color.White)
                    }
                }
            )
        },
        containerColor = ConcreteBackground
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize().padding(innerPadding)) {
            if (uiState.registrations.isEmpty() && !uiState.isLoading) {
                EmptyStateView(
                    message = "No pending worker registrations to review",
                    icon = Icons.Default.CheckCircleOutline
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(uiState.registrations) { reg ->
                        RegistrationCardItem(
                            registration = reg,
                            onClick = { viewModel.selectRegistration(reg) }
                        )
                    }
                }
            }

            LoadingOverlay(isLoading = uiState.isLoading)

            ErrorDialog(
                errorMessage = uiState.errorMessage,
                onDismiss = viewModel::dismissError
            )

            // Review Modal
            uiState.selectedRegistration?.let { reg ->
                val data = reg.submittedData
                AlertDialog(
                    onDismissRequest = { viewModel.selectRegistration(null) },
                    title = {
                        Text(
                            text = "Review Registration: ${data.fullName}",
                            fontWeight = FontWeight.Bold,
                            color = ConstructionSlate
                        )
                    },
                    text = {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Proposed ID: ${reg.workerId}", fontWeight = FontWeight.SemiBold)
                                StatusBadge(reg.status.name)
                            }
                            HorizontalDivider(color = ConcreteBorder)
                            Text("Trade: ${data.jobRole}", color = ConstructionSteel)
                            Text("Batch: ${data.batchNumber}", color = ConstructionSteel)
                            Text("Target Site: ${data.siteId}", color = ConstructionSteel)
                            Text("Phone: ${data.phone}", color = ConstructionSteel)
                            Text("Email: ${data.email}", color = ConstructionSteel)
                            Text("Address: ${data.address}", color = ConstructionSteel)
                            Text("Emergency Contact: ${data.emergencyContactName} (${data.emergencyContactPhone})", color = ConstructionSteel)
                        }
                    },
                    confirmButton = {
                        Button(
                            onClick = { viewModel.approve(reg.registrationId) },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusActiveGreen)
                        ) {
                            Text("Approve Worker", color = Color.White)
                        }
                    },
                    dismissButton = {
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = { viewModel.reject(reg.registrationId) },
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRejectedRed)
                            ) {
                                Text("Reject")
                            }
                            TextButton(onClick = { viewModel.suspendRegistration(reg.registrationId) }) {
                                Text("Suspend", color = SafetyAmberDark)
                            }
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    containerColor = Color.White
                )
            }
        }
    }
}

@Composable
fun RegistrationCardItem(registration: WorkerRegistration, onClick: () -> Unit) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = ConcreteSurface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onClick)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = registration.submittedData.fullName,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = ConstructionSlate
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "ID: ${registration.workerId} • ${registration.submittedData.jobRole} • Batch ${registration.submittedData.batchNumber}",
                    style = MaterialTheme.typography.bodySmall,
                    color = ConstructionSteel
                )
            }
            StatusBadge(registration.status.name)
        }
    }
}
