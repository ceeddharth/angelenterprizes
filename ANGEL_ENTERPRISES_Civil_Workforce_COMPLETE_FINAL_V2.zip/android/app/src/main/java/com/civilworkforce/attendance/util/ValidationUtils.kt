package com.civilworkforce.attendance.util

object ValidationUtils {

    const val MAX_EMAIL_LENGTH = 254

    // India 10-digit mobile number starting with 6, 7, 8, or 9
    // Exactly 10 digits, digits only, no +, spaces, hyphens, letters, or symbols
    private val PHONE_REGEX = Regex("^[6-9][0-9]{9}$")

    // Standard RFC 5322 compliant email regex requiring valid local part, domain name, and dot-separated extension
    // Rejects: user@, @domain.com, user@domain, multiple @, spaces, double dots
    private val EMAIL_REGEX = Regex("^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$")

    fun isValidEmail(email: String?): Boolean {
        if (email.isNullOrBlank()) return false
        val trimmed = email.trim()
        if (trimmed.length > MAX_EMAIL_LENGTH || trimmed.contains(' ')) return false
        return EMAIL_REGEX.matches(trimmed)
    }

    fun isValidPhone(phone: String?): Boolean {
        if (phone.isNullOrBlank()) return false
        return PHONE_REGEX.matches(phone)
    }

    fun normalizeEmail(email: String): String {
        return email.trim().lowercase()
    }

    fun normalizePhone(phone: String): String {
        return phone.trim()
    }

    fun isValidPassword(password: String): Boolean {
        return password.trim().length >= 6
    }

    fun isValidWorkerId(workerId: String): Boolean {
        return workerId.trim().isNotBlank() && workerId.trim().length >= 3
    }
}
