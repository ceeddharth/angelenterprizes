package com.civilworkforce.attendance.data

import com.civilworkforce.attendance.model.RegistrationStatus
import com.civilworkforce.attendance.model.Resource
import com.civilworkforce.attendance.model.SubmittedData
import com.civilworkforce.attendance.model.User
import com.civilworkforce.attendance.model.UserRole
import com.civilworkforce.attendance.model.UserStatus
import com.civilworkforce.attendance.model.Worker
import com.civilworkforce.attendance.model.WorkerRegistration
import com.civilworkforce.attendance.util.FirebaseErrorParser
import com.civilworkforce.attendance.util.ValidationUtils
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.tasks.await

interface RegistrationRepository {
    suspend fun submitWorkerRegistration(data: SubmittedData, passwordPin: String): Resource<String>
    suspend fun getPendingRegistrations(): Resource<List<WorkerRegistration>>
    suspend fun approveRegistration(registrationId: String, adminUid: String): Resource<Unit>
    suspend fun rejectRegistration(registrationId: String, adminUid: String): Resource<Unit>
    suspend fun suspendRegistration(registrationId: String, adminUid: String): Resource<Unit>
}

class FirebaseRegistrationRepository(
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(),
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) : RegistrationRepository {

    override suspend fun submitWorkerRegistration(data: SubmittedData, passwordPin: String): Resource<String> {
        return try {
            // 0. Strict Phone and Email Validation prior to Firebase Auth or Firestore operations
            if (!ValidationUtils.isValidPhone(data.phone)) {
                return Resource.Error("Mobile number must be exactly 10 digits starting with 6, 7, 8, or 9 (digits only, no +91, spaces or symbols).")
            }
            if (data.emergencyContactPhone.isNotBlank() && !ValidationUtils.isValidPhone(data.emergencyContactPhone)) {
                return Resource.Error("Emergency contact number must be exactly 10 digits starting with 6, 7, 8, or 9 (digits only, no +91, spaces or symbols).")
            }
            if (!ValidationUtils.isValidEmail(data.email)) {
                return Resource.Error("Please enter a valid email address (maximum 254 characters).")
            }

            // 1. Check duplicate Worker ID
            val workerIdCheck = firestore.collection(FirebaseConstants.COLLECTION_WORKERS)
                .whereEqualTo(FirebaseConstants.FIELD_WORKER_ID, data.workerId.trim())
                .limit(1)
                .get()
                .await()

            if (!workerIdCheck.isEmpty) {
                return Resource.Error("Worker ID '${data.workerId}' is already registered in the system. Please verify or contact administration.")
            }

            // Also check pending registrations for same Worker ID
            val pendingWorkerIdCheck = firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS)
                .whereEqualTo("workerId", data.workerId.trim())
                .whereEqualTo(FirebaseConstants.FIELD_STATUS, RegistrationStatus.PENDING.name)
                .limit(1)
                .get()
                .await()

            if (!pendingWorkerIdCheck.isEmpty) {
                return Resource.Error("An active registration for Worker ID '${data.workerId}' is already awaiting administrator review.")
            }

            // 2. Check duplicate phone
            val phoneCheck = firestore.collection(FirebaseConstants.COLLECTION_WORKERS)
                .whereEqualTo(FirebaseConstants.FIELD_PHONE, data.phone.trim())
                .limit(1)
                .get()
                .await()

            if (!phoneCheck.isEmpty) {
                return Resource.Error("Mobile number '${data.phone}' is already registered with another worker profile.")
            }

            // 3. Create Firebase Authentication credentials for worker
            val authResult = auth.createUserWithEmailAndPassword(data.email.trim(), passwordPin).await()
            val uid = authResult.user?.uid ?: throw IllegalStateException("Firebase Auth UID generation failed")

            // Critical: Sign out immediately so registration does NOT grant automatic access upon submission
            auth.signOut()

            // 4. Create user record with PENDING status
            val userRecord = User(
                uid = uid,
                role = UserRole.WORKER,
                name = data.fullName.trim(),
                email = data.email.trim(),
                phone = data.phone.trim(),
                status = UserStatus.PENDING,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            firestore.collection(FirebaseConstants.COLLECTION_USERS).document(uid).set(userRecord).await()

            // 5. Create registration document in workerRegistrations
            val regRef = firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS).document()
            val registration = WorkerRegistration(
                registrationId = regRef.id,
                workerId = data.workerId.trim(),
                submittedData = data,
                status = RegistrationStatus.PENDING,
                submittedAt = Timestamp.now()
            )
            regRef.set(registration).await()

            Resource.Success(regRef.id)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun getPendingRegistrations(): Resource<List<WorkerRegistration>> {
        return try {
            val snapshot = firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS)
                .whereEqualTo(FirebaseConstants.FIELD_STATUS, RegistrationStatus.PENDING.name)
                .orderBy(FirebaseConstants.FIELD_SUBMITTED_AT)
                .get()
                .await()

            Resource.Success(snapshot.toObjects(WorkerRegistration::class.java))
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun approveRegistration(registrationId: String, adminUid: String): Resource<Unit> {
        return try {
            val regRef = firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS).document(registrationId)
            val regDoc = regRef.get().await()
            if (!regDoc.exists()) {
                return Resource.Error("Registration record not found.")
            }

            val reg = regDoc.toObject(WorkerRegistration::class.java)
                ?: return Resource.Error("Malformed registration data.")

            val sub = reg.submittedData

            // Find matching user by email
            val userQuery = firestore.collection(FirebaseConstants.COLLECTION_USERS)
                .whereEqualTo(FirebaseConstants.FIELD_EMAIL, sub.email.trim())
                .limit(1)
                .get()
                .await()

            val uid = if (!userQuery.isEmpty) {
                userQuery.documents.first().id
            } else ""

            val batch = firestore.batch()

            // Update registration document
            batch.update(regRef, mapOf(
                FirebaseConstants.FIELD_STATUS to RegistrationStatus.APPROVED.name,
                "reviewedAt" to Timestamp.now(),
                "reviewedBy" to adminUid
            ))

            // Update user document if exists
            if (uid.isNotBlank()) {
                val userRef = firestore.collection(FirebaseConstants.COLLECTION_USERS).document(uid)
                batch.update(userRef, mapOf(
                    FirebaseConstants.FIELD_STATUS to UserStatus.ACTIVE.name,
                    FirebaseConstants.FIELD_UPDATED_AT to Timestamp.now()
                ))
            }

            // Create worker document in /workers/{workerId}
            val workerRef = firestore.collection(FirebaseConstants.COLLECTION_WORKERS).document(reg.workerId)
            val newWorker = Worker(
                workerId = reg.workerId,
                uid = uid,
                fullName = sub.fullName,
                phone = sub.phone,
                email = sub.email,
                batchNumber = sub.batchNumber,
                jobRole = sub.jobRole,
                siteId = sub.siteId,
                dateOfBirth = sub.dateOfBirth,
                address = sub.address,
                emergencyContactName = sub.emergencyContactName,
                emergencyContactPhone = sub.emergencyContactPhone,
                joiningDate = sub.joiningDate,
                status = UserStatus.ACTIVE,
                createdAt = Timestamp.now(),
                updatedAt = Timestamp.now()
            )
            batch.set(workerRef, newWorker)

            batch.commit().await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun rejectRegistration(registrationId: String, adminUid: String): Resource<Unit> {
        return try {
            val regRef = firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS).document(registrationId)
            val regDoc = regRef.get().await()
            if (!regDoc.exists()) return Resource.Error("Registration not found.")

            val reg = regDoc.toObject(WorkerRegistration::class.java)

            val batch = firestore.batch()
            batch.update(regRef, mapOf(
                FirebaseConstants.FIELD_STATUS to RegistrationStatus.REJECTED.name,
                "reviewedAt" to Timestamp.now(),
                "reviewedBy" to adminUid
            ))

            if (reg != null) {
                val userQuery = firestore.collection(FirebaseConstants.COLLECTION_USERS)
                    .whereEqualTo(FirebaseConstants.FIELD_EMAIL, reg.submittedData.email.trim())
                    .limit(1)
                    .get()
                    .await()

                if (!userQuery.isEmpty) {
                    val userRef = firestore.collection(FirebaseConstants.COLLECTION_USERS).document(userQuery.documents.first().id)
                    batch.update(userRef, mapOf(
                        FirebaseConstants.FIELD_STATUS to UserStatus.REJECTED.name,
                        FirebaseConstants.FIELD_UPDATED_AT to Timestamp.now()
                    ))
                }
            }

            batch.commit().await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }

    override suspend fun suspendRegistration(registrationId: String, adminUid: String): Resource<Unit> {
        return try {
            firestore.collection(FirebaseConstants.COLLECTION_REGISTRATIONS)
                .document(registrationId)
                .update(mapOf(
                    FirebaseConstants.FIELD_STATUS to RegistrationStatus.SUSPENDED.name,
                    "reviewedAt" to Timestamp.now(),
                    "reviewedBy" to adminUid
                )).await()
            Resource.Success(Unit)
        } catch (e: Exception) {
            Resource.Error(FirebaseErrorParser.parse(e), e)
        }
    }
}
