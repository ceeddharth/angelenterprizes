# ProGuard rules for Civil Workforce Attendance System
-keepattributes *Annotation*
-keepattributes Signature
-keepattributes InnerClasses
-keepattributes EnclosingMethod

# Firebase & Coroutines
-dontwarn com.google.firebase.**
-keep class com.google.firebase.** { *; }
-keepclassmembers class * {
    @com.google.firebase.firestore.PropertyName <fields>;
    @com.google.firebase.firestore.PropertyName <methods>;
}

# Keep Data Models
-keep class com.civilworkforce.attendance.model.** { *; }
